"""Extract transcript from YouTube videos."""
import argparse
import re
import time

from cdb_skills.output import print_success, print_error


def extract_video_id(url: str) -> str:
    """Extract video ID from various YouTube URL formats."""
    patterns = [
        r'(?:v=|/v/)([a-zA-Z0-9_-]{11})',      # youtube.com/watch?v=ID
        r'(?:youtu\.be/)([a-zA-Z0-9_-]{11})',    # youtu.be/ID
        r'(?:embed/)([a-zA-Z0-9_-]{11})',         # youtube.com/embed/ID
        r'(?:shorts/)([a-zA-Z0-9_-]{11})',        # youtube.com/shorts/ID
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return url.strip()  # Assume raw ID


def main():
    parser = argparse.ArgumentParser(description="Extract transcript from YouTube video")
    parser.add_argument("--url", required=True, help="YouTube URL or video ID")
    parser.add_argument("--language", default="de,en",
                        help="Preferred languages, comma-separated (default: de,en)")
    parser.add_argument("--format", default="text", choices=["text", "timestamped", "srt"],
                        dest="output_format",
                        help="Output format: text (plain), timestamped (with times), srt (subtitle format)")
    args = parser.parse_args()

    try:
        start = time.time()

        from youtube_transcript_api import YouTubeTranscriptApi
        from youtube_transcript_api.formatters import TextFormatter, SRTFormatter

        video_id = extract_video_id(args.url)
        languages = [l.strip() for l in args.language.split(",")]

        ytt = YouTubeTranscriptApi()
        transcript = ytt.fetch(video_id, languages=languages)

        if args.output_format == "text":
            result = TextFormatter().format_transcript(transcript)
        elif args.output_format == "srt":
            result = SRTFormatter().format_transcript(transcript)
        elif args.output_format == "timestamped":
            lines = []
            for snippet in transcript:
                mins = int(snippet.start // 60)
                secs = int(snippet.start % 60)
                lines.append(f"[{mins:02d}:{secs:02d}] {snippet.text}")
            result = "\n".join(lines)

        duration_ms = int((time.time() - start) * 1000)

        print_success(result, metadata={
            "tool": "youtube.transcript",
            "duration_ms": duration_ms,
            "video_id": video_id,
            "format": args.output_format,
            "snippet_count": len(transcript),
        })
    except Exception as e:
        error_msg = str(e)
        if "No transcript" in error_msg or "TranscriptsDisabled" in error_msg:
            error_msg = f"Kein Transkript verfuegbar fuer Video {args.url}. Moeglicherweise hat das Video keine Untertitel."
        print_error(error_msg, details={
            "tool": "youtube.transcript",
            "error_type": type(e).__name__,
        })


if __name__ == "__main__":
    main()
