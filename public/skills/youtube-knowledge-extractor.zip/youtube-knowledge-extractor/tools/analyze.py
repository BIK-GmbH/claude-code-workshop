"""Analyze a YouTube video — transcript + AI analysis in one step."""
import argparse
import re
import time

from cdb_skills.llm import complete
from cdb_skills.output import print_success, print_error


def extract_video_id(url: str) -> str:
    """Extract video ID from various YouTube URL formats."""
    patterns = [
        r'(?:v=|/v/)([a-zA-Z0-9_-]{11})',
        r'(?:youtu\.be/)([a-zA-Z0-9_-]{11})',
        r'(?:embed/)([a-zA-Z0-9_-]{11})',
        r'(?:shorts/)([a-zA-Z0-9_-]{11})',
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return url.strip()


ANALYSIS_PROMPT = """Analyze the following YouTube video transcript and create a structured knowledge document.

Video URL: {url}

Transcript:
{transcript}

Create the following sections in {language}:

## Zusammenfassung
2-3 paragraphs capturing the core of the video.

## Key Learnings
Numbered list of the most important takeaways with explanations.

## Konzepte & Frameworks
Any mental models, methodologies, or frameworks explained.

## Tools & Technologien
Software, libraries, APIs, services mentioned — with brief description.

## Actionable Steps
Concrete things the viewer can do/try as a checklist.

## Zitate
Notable quotes worth preserving.

Output ONLY the structured markdown, no preamble."""


def main():
    parser = argparse.ArgumentParser(description="Analyze YouTube video (transcript + AI analysis)")
    parser.add_argument("--url", required=True, help="YouTube URL or video ID")
    parser.add_argument("--language", default="de",
                        help="Output language for analysis (default: de)")
    parser.add_argument("--transcript-language", default="de,en", dest="transcript_lang",
                        help="Preferred transcript languages (default: de,en)")
    args = parser.parse_args()

    try:
        start = time.time()

        from youtube_transcript_api import YouTubeTranscriptApi
        from youtube_transcript_api.formatters import TextFormatter

        video_id = extract_video_id(args.url)
        languages = [l.strip() for l in args.transcript_lang.split(",")]

        # Step 1: Get transcript
        ytt = YouTubeTranscriptApi()
        transcript = ytt.fetch(video_id, languages=languages)
        plain_text = TextFormatter().format_transcript(transcript)

        # Step 2: Analyze with LLM
        prompt = ANALYSIS_PROMPT.format(
            url=args.url,
            transcript=plain_text[:30000],  # Limit to ~30k chars
            language=args.language,
        )
        analysis = complete(prompt)

        duration_ms = int((time.time() - start) * 1000)

        print_success(analysis, metadata={
            "tool": "youtube.analyze",
            "duration_ms": duration_ms,
            "video_id": video_id,
            "transcript_length": len(plain_text),
            "snippet_count": len(transcript),
        })
    except Exception as e:
        error_msg = str(e)
        if "No transcript" in error_msg or "TranscriptsDisabled" in error_msg:
            error_msg = f"Kein Transkript verfuegbar fuer Video {args.url}."
        print_error(error_msg, details={
            "tool": "youtube.analyze",
            "error_type": type(e).__name__,
        })


if __name__ == "__main__":
    main()
