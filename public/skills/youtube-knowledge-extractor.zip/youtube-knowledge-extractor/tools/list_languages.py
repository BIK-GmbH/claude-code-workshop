"""List available transcript languages for a YouTube video."""
import argparse
import re
import time

from cdb_skills.output import print_success, print_error


def extract_video_id(url: str) -> str:
    patterns = [
        r'(?:v=|/v/)([a-zA-Z0-9_-]{11})',
        r'(?:youtu\.be/)([a-zA-Z0-9_-]{11})',
        r'(?:embed/)([a-zA-Z0-9_-]{11})',
        r'(?:shorts/)([a-zA-Z0-9_-]{11})',
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return url.strip()


def main():
    parser = argparse.ArgumentParser(description="List available transcript languages for a YouTube video")
    parser.add_argument("--url", required=True, help="YouTube URL or video ID")
    args = parser.parse_args()

    try:
        start = time.time()

        from youtube_transcript_api import YouTubeTranscriptApi

        video_id = extract_video_id(args.url)
        ytt = YouTubeTranscriptApi()
        transcript_list = ytt.list(video_id)

        languages = []
        for t in transcript_list:
            languages.append({
                "language": t.language,
                "language_code": t.language_code,
                "is_generated": t.is_generated,
                "is_translatable": t.is_translatable,
            })

        duration_ms = int((time.time() - start) * 1000)

        result = "\n".join(
            f"- **{l['language']}** ({l['language_code']}) — {'auto-generated' if l['is_generated'] else 'manual'}"
            for l in languages
        )

        print_success(result, metadata={
            "tool": "youtube.list_languages",
            "duration_ms": duration_ms,
            "video_id": video_id,
            "language_count": len(languages),
            "languages": languages,
        })
    except Exception as e:
        print_error(str(e), details={
            "tool": "youtube.list_languages",
            "error_type": type(e).__name__,
        })


if __name__ == "__main__":
    main()
