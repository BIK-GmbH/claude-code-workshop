"""Tests for YouTube knowledge extractor tools."""
import subprocess
import sys
from pathlib import Path

TOOLS_DIR = str(Path(__file__).parent.parent / "tools")


def test_transcript_help():
    result = subprocess.run(
        [sys.executable, f"{TOOLS_DIR}/transcript.py", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "--url" in result.stdout
    assert "--language" in result.stdout
    assert "--format" in result.stdout


def test_analyze_help():
    result = subprocess.run(
        [sys.executable, f"{TOOLS_DIR}/analyze.py", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "--url" in result.stdout


def test_list_languages_help():
    result = subprocess.run(
        [sys.executable, f"{TOOLS_DIR}/list_languages.py", "--help"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0
    assert "--url" in result.stdout
